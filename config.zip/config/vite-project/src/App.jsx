import Configuracoes from './components/Configuracoes'
import './App.css'

function App() {

  return (
    <>
      <Configuracoes/>
    </>
  )
}

export default App

