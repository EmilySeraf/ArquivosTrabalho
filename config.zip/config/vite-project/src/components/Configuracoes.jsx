
export default function Configuracoes(){
    return(
        <>
        <header>
            <h1>Talent ShowCase</h1>
            <img src="Casa.png" alt="" />
        </header>
        <br /><br />
        <div className="container">
            <img src="Alicia.png" className="Alicia" />
            <div className="inputs">
            <input type="text" placeholder=" Nome"/>
            <input type="text" placeholder=" Nome de usuário"/>
            <input type="text" placeholder=" Gênero de perfil"/>
            </div>
            </div>
            <div>
            <div className="bio">
            <label>Biografia</label>
            <input type="text"/>
            </div>
            </div>
   </>
)
}
