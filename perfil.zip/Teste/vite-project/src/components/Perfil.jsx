
export default function Perfil(){
    return(
        <>
        <header>
            <h1>Talent ShowCase</h1>
            <img src="Casa.png" alt="" />
        </header>
        <br /><br />
        <div className="container">
            <img src="Alicia.png" className="Alicia" />
            <div className="texto">
            <h2>Olá, Alícia Bittencourt </h2>
            <div class="button-container">
            <button class="btn config">Configurações</button>
            <button class="btn saldo">Saldo</button>
            </div>
            </div>
            </div>
            <br />
            <div className="postagens">
            <h3>Minhas Postagens:</h3>
            <hr />
            <div className="videos">
            <img src="foto01.png"  />
            <img src="foto02.png"  />
            <img src="foto03.png"  />
            <img src="foto04.png"  />
            <button>Mais</button>
            </div>
            </div>

   </>
)
}
