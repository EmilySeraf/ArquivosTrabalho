import Perfil from './components/Perfil'
import './App.css'

function App() {

  return (
    <>
      <Perfil/>
    </>
  )
}

export default App
